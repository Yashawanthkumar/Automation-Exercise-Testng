package com.ea.framework.base;

/**
 * Created by kkr on 11/27/2016.
 */

public enum BrowserType {
    Firefox,
    Chrome,
    IE,
    Safari
}
