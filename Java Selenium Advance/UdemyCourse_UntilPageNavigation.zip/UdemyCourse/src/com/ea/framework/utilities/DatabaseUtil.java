package com.ea.framework.utilities;

/**
 * Created by Karthik-PC on 11/23/2016.
 */
public class DatabaseUtil {
}
