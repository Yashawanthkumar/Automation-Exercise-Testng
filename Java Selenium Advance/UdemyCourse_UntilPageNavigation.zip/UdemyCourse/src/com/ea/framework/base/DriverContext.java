package com.ea.framework.base;

import org.openqa.selenium.WebDriver;

/**
 * Created by Karthik-PC on 11/23/2016.
 */
public class DriverContext {


    public static WebDriver Driver;


}
